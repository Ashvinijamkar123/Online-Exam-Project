import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private httpclient:HttpClient)
   {

    }
    validate(user:User)
    {
      return this.httpclient.post<boolean>("http://localhost:8000/examapi/validate/",user);
      
    }

    getAllSubjects()
    {
       return this.httpclient.get<string[]>("http://localhost:8000/examapi/getAllSubjects/")
    }

    
  
}
    export class User
    {
      username:string;
      password:string;
      mobno:number;
      emailid:string;

      constructor(username:string,password:string,mobno:number,emailid:string)
      {
        this.username=username;
        this.password=password;
        this.emailid=emailid;
        this.mobno=mobno;
      }

    }

