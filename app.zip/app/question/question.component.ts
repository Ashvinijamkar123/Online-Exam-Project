import { Component, OnInit } from '@angular/core';
import { Answer, Question, QuestionService } from '../question.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Result } from '../admin.service';

@Component({
  selector: 'app-question',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './question.component.html',
  styleUrl: './question.component.css'
})
export class QuestionComponent implements OnInit
{
  index:number=0;
  subject:any='';
  questions:Question[]=[]
  question:Question=new Question(0,'','','','','','','');
  submittedAnswer:string='';
  allAnswers:Answer[]=[];
  username:any='';


  selected:boolean=false;

  duration:any=181;// 181 seconds
  durationMessage='';
  durationInterval:any='';
  // username: string | null;


  constructor(private questionservice:QuestionService,private router:Router)
  {
      this.subject=sessionStorage.getItem('subject');
      
      console.log("subject is "+this.subject);

      this.username=sessionStorage.getItem('username');

      
      this.durationInterval=setInterval(()=>
        {

          this.duration=this.duration-1;// 178
         
          var minutes= Math.floor(this.duration/60);//2
          var seconds=this.duration%60;// 58

          this.durationMessage=minutes + ":" + seconds ;//2:58 

          if(this.duration==0)
            this.endexam();


        },1000);// after 1 sec setInterval will execute given arrow function

  }


  ngOnInit(): void 
  {
    // [ [] question array   subscribe() ]  observable object

    this.questionservice.getAllQuestions(this.subject).subscribe(array=> { this.questions=array ; this.question=this.questions[0]; });
  }

  // 0  1  2




  getColor(option:string)
  {
      //console.log(this.allAnswers.length);

        for(var i=0;i<this.allAnswers.length;i++)
        {
            let answer=this.allAnswers[i];

  //          console.log(answer.submittedAnswer + " " + option);

            if(answer.qno == this.question.qno && answer.submittedAnswer.trim()==option.trim())
            {
                return "green";

            }
        }


        return "red";
  }


  
  isChecked(option:string)
  {
      //console.log(this.allAnswers.length);

        for(var i=0;i<this.allAnswers.length;i++)
        {
            let answer=this.allAnswers[i];

           console.log(answer.submittedAnswer + " " + option);

            if(answer.qno == this.question.qno && answer.submittedAnswer.trim()==option.trim())
            {
              
                return true;

            }
        }

        return false;
  }
  nextQuestion()
  {
  
    if(this.index<this.questions.length-1)
    {
         this.index=this.index+1;
         this.question=this.questions[this.index];
    }
    else
    {
        this.question=this.questions[this.questions.length-1];
    }

  }

  previousQuestion()
  {
    
      if(this.index>0)
      {
        this.index=this.index-1;

        this.question=this.questions[this.index];
      }
      else
      {
        this.question=this.questions[0];
      }

  }


  saveAnswer()
  {
    let answer=new Answer(this.question.qno,this.question.qtext,this.submittedAnswer,this.question.answer)

    let indexofelement=this.allAnswers.findIndex(answerfromallAnswer=>answerfromallAnswer.qno==answer.qno);

    if(indexofelement==-1)
    {
        this.allAnswers.push(answer);
    }
    else
    {
      this.allAnswers[indexofelement].submittedAnswer=answer.submittedAnswer
    }

    console.log(JSON.stringify(this.allAnswers))

  }


  endexam()
  {
    let score=0;

    for (var i=0;i<this.allAnswers.length;i++) 
    {
      var answer=this.allAnswers[i];

      console.log(answer.submittedAnswer + " " + answer.correctAnswer);
      
      if(answer.submittedAnswer==answer.correctAnswer)
        {
            score=score+1;
            console.log(score)
        }
  
    }
    
    var result=new Result(this.username,this.subject,score);

    this.questionservice.saveResult(result).subscribe();
    
    this.router.navigate(['score'],{queryParams:{'score':score,'allanswers':JSON.stringify(this.allAnswers)}});
  }

  }






