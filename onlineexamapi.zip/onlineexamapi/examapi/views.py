from django.shortcuts import render
from requests import Response
from django.db import connection
from django.http import HttpResponse
from examapi.models import Admin, Question, Users,Result, Users

from examapi.serilization import QuestionSerilicer,ResultSerilizers, UsersSerilizers

from rest_framework.decorators import api_view # type: ignore
from rest_framework.response import Response # type: ignore
from array import *
# Create your views here.
@api_view(['GET'])
def getAllSubjects(request):

    listofsubjects=Question.objects.all().values('subject')
    
    print(listofsubjects)
    
    subjects=[]

    for dictionary in listofsubjects:
         
         for value in dictionary.values():
              subjects.append(value)
         
    return Response(set(subjects))




@api_view(['post'])
def validate(request):
    userfromclient=request.data
    print(userfromclient)

    # data comming from browser while log in
    userfromdb=Users.objects.get(username=userfromclient['username'])

    print(userfromdb) 
    if userfromclient["username"]==userfromdb.username and userfromclient["password"]==userfromdb.password:
        return Response(True)   
    else: 
        return Response(False)
    
@api_view(['post'])
def validate2(request):

    userfromclient=request.data   # data coming from browser while log in

    print(userfromclient)

    userfromdb=Admin.objects.get(username=userfromclient["username"])

    print(userfromdb)

    # username	password	mobno	emailid
    #   x	     y	        123	   x@hjhjjk     data from database

    print(type(userfromclient["password"]))
    print(type(userfromdb.password))

    if userfromclient["username"]==userfromdb.username and int(userfromclient["password"])==userfromdb.password:
        return Response(True) # response will be given to angular and then angular will show question page
    else:
        return Response(False) # response will be given to angular and then angular will show login page with error message


    
    
    
@api_view(['GET'])
def getAllQuestions(request,subject):
    print(subject)
    allquestions=Question.objects.filter(subject=subject)
    serilizer=QuestionSerilicer(allquestions,many=True)
    return Response(serilizer.data) 



@api_view(['GET'])
def viewQuestion(request,qno,subject):
    question=Question.objects.get(qno=qno,subject=subject)
    return Response(QuestionSerilicer(question).data)


@api_view(['POST'])
def addQuestion(request):

    Question.objects.create(qno=request.data["qno"],qtext=request.data["qtext"],op1=request.data["op1"],op2=request.data["op2"],op3=request.data["op3"],op4=request.data["op4"],subject=request.data["subject"],answer=request.data["answer"])
    print(connection.queries)

    return Response(True)


@api_view(['PUT'])
def updateQuestion(request):
    
    questionFromClient=request.data

    queryset=Question.objects.filter(qno=questionFromClient["qno"] ,subject=questionFromClient["subject"])
    
    queryset.update(qtext=request.data["qtext"],op1=request.data["op1"],op2=request.data["op2"],op3=request.data["op3"],op4=request.data["op4"],answer=request.data["answer"])

    return Response(True)    


@api_view(['DELETE'])
def deleteQuestion(request,qno,subject):
    
    Question.objects.filter(qno=qno,subject=subject).delete()

    return Response(True) 

@api_view(['post'])
def saveResult(request):

    print(request.data)

    serilizer=ResultSerilizers(data=request.data)

    if serilizer.is_valid():
        print(connection.queries)
        serilizer.save()
        
    return Response(request.data) 


@api_view(["GET"])
def getResults2(request,subject,pageno):

    print("given subject is  " + str(len(subject)))

    myresult=Result.objects.filter(subject=subject)

    print(myresult.query)

    noofrecords=myresult.__len__()
    
    print("no of records are " + str(noofrecords))
    
    # how many pages are required to show results

    pagenumber = 1#4

    while (3 * pagenumber) < noofrecords:
                        pagenumber += 1

    
    indexlist = list() #[]

    count=0

    print("pagenumber is " , str(pagenumber))

    for i in range(0,pagenumber):
                indexlist.append(count)
                count = count + 3
    
    print(indexlist)
    
    startindex=indexlist[int(pageno)-1]

    allrecords=list(Result.objects.filter(subject=subject))

    if pageno==pagenumber:
           totalrecordsshown = 3*(pagenumber - 1)
           recordstoshow = noofrecords - totalrecordsshown
           endindex=startindex+recordstoshow

           allresults=allrecords[startindex:endindex]
           serilizer=ResultSerilizers(allresults,many=True)
           return Response(serilizer.data)
           
    else:
          endindex=startindex+3
          allresults=allrecords[startindex:endindex]
          serilizer=ResultSerilizers(allresults,many=True)
          return Response(serilizer.data)
    

    
@api_view(["GET"])
def getResults(request,subject):
    allresults=Result.objects.filter(subject=subject)
    serilizer=ResultSerilizers(allresults,many=True)
    return Response(serilizer.data)


@api_view(["GET"])
def getRecordsCounts(request,subject):

    count=Result.objects.filter(subject=subject).__len__()
    return Response(count)

          

    
				
