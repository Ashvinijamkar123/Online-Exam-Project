from examapi.models import Admin, Question, Result, Users
from rest_framework import serializers 

 
class QuestionSerilicer(serializers.ModelSerializer):
                                       
    class Meta:
            model=Question
            fields='__all__'

class UsersSerilizers(serializers.ModelSerializer):
      
      class Meta:
            model=Users
            fields='__all__'

class AdminSerilizer(serializers.ModelSerializer):
      
      class Meta:
            model=Admin
            fields='__all__'


class ResultSerilizers(serializers.ModelSerializer):
      
      class Meta:
            model=Result
            fields='__all__'

